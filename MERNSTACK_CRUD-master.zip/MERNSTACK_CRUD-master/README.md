# MERNSTACK_CRUD

makesure you have successfully configured mongoDB at local 
go into backend folder and start backend server e.g. nodemon server.js or node server.js
and also go in frontend folder and start frontend server e.g. npm start
